# PracticaAnimation
Animacion con XML
